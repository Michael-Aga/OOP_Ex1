# OOP_2021
The OOP course (Object Oriented Programming & Design. - Ariel University) is designed to teach Computer Science students with Java background the art of proper agile programming both in Java and in Python. The course is designed as a "project-paced-learning" (aka BPL) it consists of 6 Object Oriented Designing and Programming assignments - which will teach (hands on) the students good practice of OOP, OOD, Agile (Xtream) Programming, while working on large scale software project Using Github.
This repository is dedicated for Object-Oriented Programming course. It contains Class and TA examples, as well as many assignments related examples. The main motivation for this repository is teaching and education of students to become good programmers and even better software designers.

Code standards: 

Java: https://github.com/twitter-archive/commons/blob/master/src/java/com/twitter/common/styleguide.md

Python: https://google.github.io/styleguide/pyguide.html
