# OOP: Intro to Python_101, for java programmers
print("Hello world!!")
a = 3+4
b = 5*a
print("b="+str(b))
b = True
print(a==7)
s = "Hello World!!"
s2 = s.lower()
l = len(s2)
print(s2+" length: "+str(l)+"  "+s2[1])
w = s[6:9]
i = s.index(w)
print("the index = "+w+" in "+s+" is "+str(i))