# 1. Comments
# This is a comment.
print("Hello, World!")

# 2. Docstrings
""" This is a
multiline docstring."""

# 3. Indentations is a must in python
if 5 > 2:
    print("Five is greater than two!")

## Wont Work

# if 5 > 2:
# print("Five is greater than two!") #doesn't work

# if 5 > 2:
#         print("Five is greater than two!")
#     print("six is greater than two!")#doesn't work
####################################################
