from enum import Enum


class Block(Enum):
    grass = 1
    stone = 2
    brick = 3
    dirt = 4

