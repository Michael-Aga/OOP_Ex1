# java-chat
A simple java chat application

> Java Chat is a simple chat program  
> which allows for a server with multiple
> The original code is from: https://github.com/pchampio/java-chat
> client programs to join.
        <ul>
        <li><b>@nickname</b> sending a private MSG to client @nickname'</li>
        <li><b>#d3961b</b> change color - see list of colors in the code</li>
        </ul><br/>



<p align="center">
  <a href="https://github.com/benmoshe/OOP_Ariel/blob/master/Class78/src/java_chat/screen.png">
    <img alt="ScreenShot~ prompt" src="https://github.com/benmoshe/OOP_Ariel/blob/master/Class78/src/java_chat/screen.png">
  </a>
</p>
