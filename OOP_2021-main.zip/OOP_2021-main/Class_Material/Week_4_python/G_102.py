"""Set: a simple example"""

a = {1,4,3,-4, "sde",0}
print(type(a))
print(a)
print(dir(a))
a.add(3)
print(a)
